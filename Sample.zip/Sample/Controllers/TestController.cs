﻿using ConfigAssist.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Xml;
using System.Xml.Serialization;

namespace ConfigAssist.Controllers
{
    public class TestController : ApiController
    {
        public string Get()
        {
            Features features = new Features()
            {
                ComputerName = "$app1$",
                Feature = new Feature[]
                {                   
                    new Feature()
                    {
                        Name="Test",
                        Scope = "Web"
                    }
                }
            };
            var emptyNamepsaces = new XmlSerializerNamespaces(new[] { XmlQualifiedName.Empty });
            var serializer = new XmlSerializer(features.GetType());
            var settings = new XmlWriterSettings();
            settings.Indent = true;
            settings.OmitXmlDeclaration = true;

            using (var stream = new StringWriter())
            using (var writer = XmlWriter.Create(stream, settings))
            {
                serializer.Serialize(writer, features, emptyNamepsaces);
                return stream.ToString();
            }           
        }
    }
}
