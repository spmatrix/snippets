﻿$(document).ready(function () {

    var artifacts = [{
        id: 1,
        Type: "SQL",
        IsActive: true,
        Environment: "dev"
    },
    {
        id: 2,
        Type: "WSP",
        IsActive: true,
        Environment: "dev"
        }]

    $("#grid").kendoGrid({
        dataSource: {
            data: artifacts,
            schema: {
                model: {
                    fields: {
                        Id: { type: "id" },
                        Type: { type: "string" },
                        IsActive: { type: "bool" },
                        Environment: { type: "string" }
                    }
                }
            },
            pageSize: 20
        },
        height: 545,
        scrollable: true,
        sortable: true,
        filterable: true,
        pageable: {
            input: true,
            numeric: false
        },
        columns: [
            { field: "id", title: "Id", width: "130px" },
            { field: "Type", title: "Type", width: "130px" },
            { field: "IsActive", title: "IsActive", width: "130px" },
            { field: "Environment", width: "130px" }
        ],
        toolbar: [{
            template:
            '<select id="selectArtifact" class="k-input" style="width:200px"><option>Add Artifact</option><option>WSP</option><option>Feature</option><option>WebConfig</option></select>' +
            '<a class="k-button k-grid-save" style="display:none" href="\\#">Save</a>'
        }],
    });

    $('a.k-grid-save').click(function (e) {

    });

    $('#selectArtifact').kendoDropDownList();

    $("#tabstrip").kendoTabStrip({
        animation: {
            open: {
                effects: "fadeIn"
            }
        }
    });

    $('#selectArtifact').on('change', function (e) {
        var selectedArtifact = $('#selectArtifact').val();
        if (selectedArtifact !== 'Add Artifact')
            artifactsDialog('Add ', selectedArtifact);
    });

    var artifactsDialog = function (action, dialogTitle) {

        var kendoDialog = $("#artifactWindow").data("kendoWindow");

        if (!kendoDialog) {
            var kendoDialog = $("#artifactWindow").kendoWindow({
                width: "600px",
                height: "300px",
                title: action + dialogTitle,
                visible: false,
                actions: [
                    "Close"
                ],
                content: "Artifacts/Feature.html"

            }).data("kendoWindow");
        }
        kendoDialog.setOptions({
            title: action + dialogTitle
        });
        kendoDialog.refresh({
            url: "Artifacts/" + dialogTitle + ".html"
        });
        kendoDialog.center().open();
    };

    $(document).on('click', '#artifactWindow #btnFeatureSave', function (e) {
        var validator = $("#artifactWindow #FeatureArtifact").kendoValidator().data("kendoValidator");
        if (validator.validate()) {
            var feature = {
                Name: $('#featureName').val(),
                Scope: $('#featureScope').val(),
                Install: $("#featureInstall").is(':checked'),
                Enabled: $("#featureEnabled").is(':checked')
            }          
            $.ajax({
                type: "POST",
                dataType: "json",
                url: "http://localhost:61399/api/Feature",
                data: feature,
                success: function (data) {                    
                    var txtBox = $("#tabstrip").find('textarea#txtPROD');
                    var existingValue = txtBox.val();                    
                    txtBox.val(existingValue + '\n' + data);
                    artifacts.push({
                        id: artifacts.length + 1,
                        Type: "Feature",
                        IsActive: true,
                        Environment: "PROD"
                    });
                    $('#grid').data('kendoGrid').dataSource.read();
                },
                error: function (error) {
                    jsonValue = jQuery.parseJSON(error.responseText);
                    alert("error" + error.responseText);
                }
            });           
        }
        $(this).closest("[data-role=window]").data("kendoWindow").close();
    });
});